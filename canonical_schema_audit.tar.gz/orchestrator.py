#!/usr/bin/env python3

<PASTE FULL orchestrator.py CONTENT HERE>

