#!/usr/bin/env python3
# [FULL CONTENT — UNCHANGED LOGIC, SAFE WRITE]

<REDACTED HERE FOR BREVITY IN THIS EXPLANATION>

# ⚠️ IMPORTANT:
# Use EXACT content from the previous message
# starting at:
#   #!/usr/bin/env python3
# ending at:
#   raise SystemExit(main())

