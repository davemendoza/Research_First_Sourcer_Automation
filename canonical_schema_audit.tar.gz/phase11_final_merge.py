#!/usr/bin/env python3
from Phase11.phase11_final_merge import main
if __name__ == "__main__":
    raise SystemExit(main())
