#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AI Talent Engine – People Scenario Resolver (Executable, Demo-Bounded, Hard-Fail)
© 2025 L. David Mendoza

Purpose
-------
Produce a scenario-scoped PEOPLE CSV from upstream real enumeration output.

This file is REQUIRED for OpenAI-grade demos where:
- Rows are real people (no synthetic data)
- Identity columns exist (GitHub username and GitHub URL minimum)
- Output is demo-bounded and human-reviewable (25–50 people)

Inputs (default)
----------------
- outputs/people/people_master.csv

Outputs (default)
-----------------
- outputs/people/<scenario>_people_<timestamp>.csv
- outputs/people/<scenario>_discards_<timestamp>.csv
- outputs/people/<scenario>_people_status_<timestamp>.txt

Contract Behaviors
------------------
- NO placeholders
- NO synthetic people
- Hard fail on:
  - missing/empty people_master.csv
  - missing GitHub identity signals
  - output below minimum (default 25)
- Demo-bounded output by default:
  - min_rows default: 25
  - max_rows default: 50
  - if more than max_rows match, output is deterministically capped to max_rows

Scenario Logic (Option A)
-------------------------
Frontier filtering is derived from GitHub profile signals already present in people_master.csv.
This uses best-effort text fields that exist in the CSV:
- Bio, Company, Name, Location, Blog/Website
No schema assumptions beyond what is present.

Version
-------
v1.1.0-frontier-demo-bounded (2026-01-01)

Changelog
---------
- v1.1.0-frontier-demo-bounded (2026-01-01)
  - Enforce demo-bounded defaults (25–50) at resolver layer
  - Deterministically cap output to max_rows and record original candidate count
  - Replace deprecated utcnow with timezone-aware UTC timestamps
- v1.0.0-people-scenario-resolver-exec (2026-01-01)
  - Replace stub helper with executable CLI
  - Implement Frontier (Option A) signal scoring + hard-fail minimum enforcement
  - Write scenario-scoped people CSV + discards + status report
  - Enforce identity column presence with explicit rejection reasons

Validation Steps
----------------
1) Run resolver:
   python3 people_scenario_resolver.py --scenario frontier

2) Verify bounded output:
   latest=$(ls -t outputs/people/frontier_people_*.csv | head -n 1)
   python3 - <<'PY'
import pandas as pd, glob
p = sorted(glob.glob("outputs/people/frontier_people_*.csv"))[-1]
df = pd.read_csv(p)
print("rows:", len(df))
assert 25 <= len(df) <= 50, "Demo bounds violated"
req = ["GitHub_Username","GitHub_URL","Scenario","Scenario_Score"]
missing = [c for c in req if c not in df.columns]
assert not missing, f"Missing: {missing}"
print("OK")
PY

Git Commands (SSH preferred)
----------------------------
git status
git add people_scenario_resolver.py
git commit -m "Fix: demo-bounded people scenario resolver (frontier) enforces 25-50 with hard minimum"
git push
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parent
DEFAULT_PEOPLE_MASTER = REPO_ROOT / "outputs" / "people" / "people_master.csv"
DEFAULT_OUTDIR = REPO_ROOT / "outputs" / "people"

# Demo contract defaults
DEFAULT_MIN_ROWS = 25
DEFAULT_MAX_ROWS = 50


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def _hard_fail(msg: str, code: int = 2) -> None:
    print(f"\nHARD FAILURE:\n{msg}\n")
    sys.exit(code)


def _soft_print_kv(k: str, v: str) -> None:
    print(f"{k}: {v}")


def _read_csv_strict(path: Path) -> pd.DataFrame:
    if not path.exists():
        _hard_fail(f"Upstream people inventory is missing.\nExpected: {path}")
    if path.stat().st_size < 10:
        _hard_fail(f"Upstream people inventory exists but is effectively empty.\nFile: {path}")
    try:
        df = pd.read_csv(path)
    except Exception as e:
        _hard_fail(f"Failed to read upstream people inventory CSV.\nFile: {path}\nError: {e}")
    if df.empty:
        _hard_fail(f"Upstream people inventory CSV loaded but has zero rows.\nFile: {path}")
    return df


def _norm(s: str) -> str:
    if s is None:
        return ""
    return re.sub(r"\s+", " ", str(s)).strip().lower()


def _detect_identity_columns(df: pd.DataFrame) -> Dict[str, str]:
    cols = list(df.columns)
    cols_l = [c.lower().strip() for c in cols]

    username_candidates = ["github_username", "github_login", "login", "username", "user", "handle"]
    url_candidates = ["github_url", "github profile", "github_profile", "profile_url", "html_url", "url"]

    found = {"github_username_col": "", "github_url_col": ""}

    for cand in username_candidates:
        if cand in cols_l:
            found["github_username_col"] = cols[cols_l.index(cand)]
            break

    for cand in url_candidates:
        if cand in cols_l:
            found["github_url_col"] = cols[cols_l.index(cand)]
            break

    if not found["github_url_col"]:
        for i, c in enumerate(cols_l):
            if "github" in c and "url" in c:
                found["github_url_col"] = cols[i]
                break

    if not found["github_username_col"]:
        for i, c in enumerate(cols_l):
            if c in ("login", "username") or ("github" in c and "login" in c):
                found["github_username_col"] = cols[i]
                break

    return found


def _ensure_identity_columns(df: pd.DataFrame, idmap: Dict[str, str]) -> pd.DataFrame:
    out = df.copy()

    if "GitHub_Username" not in out.columns:
        src = idmap.get("github_username_col") or ""
        out["GitHub_Username"] = out[src].astype(str) if src and src in out.columns else ""

    if "GitHub_URL" not in out.columns:
        src = idmap.get("github_url_col") or ""
        out["GitHub_URL"] = out[src].astype(str) if src and src in out.columns else ""

    # Keep these columns present for downstream schema stability, but do not fabricate values.
    if "LinkedIn_URL" not in out.columns:
        out["LinkedIn_URL"] = ""
    if "Email" not in out.columns:
        out["Email"] = ""
    if "Phone" not in out.columns:
        out["Phone"] = ""

    return out


@dataclass(frozen=True)
class KeywordRule:
    keyword: str
    weight: int
    bucket: str


def _frontier_rules() -> List[KeywordRule]:
    rules: List[KeywordRule] = []

    # GPU, kernels, perf
    rules += [
        KeywordRule("flashattention", 9, "gpu"),
        KeywordRule("flash attention", 9, "gpu"),
        KeywordRule("cuda", 8, "gpu"),
        KeywordRule("triton", 8, "gpu"),
        KeywordRule("nccl", 7, "gpu"),
        KeywordRule("cutlass", 7, "gpu"),
        KeywordRule("gpu direct", 6, "gpu"),
        KeywordRule("gpudirect", 6, "gpu"),
        KeywordRule("xformers", 6, "gpu"),
        KeywordRule("kernel", 5, "gpu"),
        KeywordRule("gpu", 4, "gpu"),
    ]

    # Inference and serving
    rules += [
        KeywordRule("tensorrt-llm", 8, "inference"),
        KeywordRule("tensorrt", 7, "inference"),
        KeywordRule("tensor rt", 7, "inference"),
        KeywordRule("vllm", 8, "inference"),
        KeywordRule("ray serve", 6, "inference"),
        KeywordRule("text generation inference", 6, "inference"),
        KeywordRule("tgi", 6, "inference"),
        KeywordRule("onnxruntime", 5, "inference"),
        KeywordRule("onnx", 5, "inference"),
        KeywordRule("sglang", 6, "inference"),
        KeywordRule("llama.cpp", 5, "inference"),
        KeywordRule("gguf", 5, "inference"),
        KeywordRule("gptq", 5, "inference"),
        KeywordRule("awq", 5, "inference"),
        KeywordRule("quantization", 4, "inference"),
        KeywordRule("kv cache", 6, "inference"),
        KeywordRule("paged attention", 6, "inference"),
    ]

    # Training scale and distributed
    rules += [
        KeywordRule("deepspeed", 6, "train"),
        KeywordRule("fsdp", 6, "train"),
        KeywordRule("pipeline parallel", 5, "train"),
        KeywordRule("tensor parallel", 5, "train"),
        KeywordRule("distributed training", 5, "train"),
        KeywordRule("mixture of experts", 5, "train"),
        KeywordRule("moe", 4, "train"),
        KeywordRule("jax", 4, "train"),
        KeywordRule("pytorch", 3, "train"),
        KeywordRule("transformer", 3, "train"),
    ]

    # Organizations as weak tie-breakers only
    rules += [
        KeywordRule("openai", 3, "org"),
        KeywordRule("anthropic", 3, "org"),
        KeywordRule("deepmind", 3, "org"),
        KeywordRule("google brain", 3, "org"),
        KeywordRule("nvidia", 2, "org"),
        KeywordRule("meta ai", 2, "org"),
        KeywordRule("mistral", 2, "org"),
    ]

    return rules


def _build_df_cols_lower(df: pd.DataFrame) -> Dict[str, str]:
    m: Dict[str, str] = {}
    for c in df.columns:
        m[c.lower().strip()] = c
    return m


def _concat_text_fields(row: pd.Series, df_cols_lower: Dict[str, str]) -> str:
    candidate_cols = [
        "bio",
        "company",
        "name",
        "location",
        "blog",
        "website",
        "homepage",
        "summary",
        "headline",
        "description",
        "notes",
    ]

    parts: List[str] = []
    for c in candidate_cols:
        if c in df_cols_lower:
            val = row.get(df_cols_lower[c])
            if pd.notna(val):
                parts.append(str(val))
    return _norm(" ".join(parts))


def _score_frontier(text: str, rules: List[KeywordRule]) -> Tuple[int, Dict[str, int], List[str]]:
    score = 0
    bucket_hits: Dict[str, int] = {}
    matched: List[str] = []

    for r in rules:
        if r.keyword in text:
            score += r.weight
            bucket_hits[r.bucket] = bucket_hits.get(r.bucket, 0) + 1
            matched.append(r.keyword)

    return score, bucket_hits, matched


def _validate_identity_row(username: str, url: str) -> Tuple[bool, str]:
    u = _norm(username)
    pu = _norm(url)

    if not u and not pu:
        return False, "missing_github_username_and_url"

    if not u and pu and "github.com/" not in pu:
        return False, "github_url_not_profile_like"

    if u and (len(u) < 2 or " " in u or "/" in u):
        return False, "github_username_invalid_format"

    return True, ""


def resolve_people_scenario(
    scenario: str,
    people_master_path: Path,
    outdir: Path,
    min_rows: int,
    max_rows: int,
) -> Path:
    scenario = scenario.strip().lower()
    if not scenario:
        _hard_fail("Scenario is required (e.g., --scenario frontier).")

    if scenario != "frontier":
        _hard_fail(
            f"Unsupported scenario '{scenario}' for people resolution.\n"
            "This resolver currently implements Option A for 'frontier' only."
        )

    if min_rows <= 0:
        _hard_fail("min_rows must be > 0.")
    if max_rows <= 0:
        _hard_fail("max_rows must be > 0.")
    if min_rows > max_rows:
        _hard_fail(f"Invalid bounds: min_rows ({min_rows}) > max_rows ({max_rows}).")

    rules = _frontier_rules()

    print(f"Scenario (people): {scenario}")
    _soft_print_kv("People master", str(people_master_path))
    _soft_print_kv("Outdir", str(outdir))
    _soft_print_kv("Min required rows", str(min_rows))
    _soft_print_kv("Max rows (demo cap)", str(max_rows))
    print(f"Frontier rules: {len(rules)} keyword signals")

    df = _read_csv_strict(people_master_path)
    print(f"Loaded upstream people rows (excluding header): {len(df)}")

    idmap = _detect_identity_columns(df)
    df_cols_lower = _build_df_cols_lower(df)

    df = _ensure_identity_columns(df, idmap)

    if "GitHub_Username" not in df.columns or "GitHub_URL" not in df.columns:
        _hard_fail("Internal error: canonical GitHub identity columns were not created.")

    accepted_rows: List[dict] = []
    discard_rows: List[dict] = []
    keyword_freq: Dict[str, int] = {}

    for idx, row in df.iterrows():
        gh_user = str(row.get("GitHub_Username", "") or "")
        gh_url = str(row.get("GitHub_URL", "") or "")
        ok_id, id_reason = _validate_identity_row(gh_user, gh_url)

        if not ok_id:
            discard_rows.append(
                {
                    "row_index": idx,
                    "reason": id_reason,
                    "GitHub_Username": gh_user,
                    "GitHub_URL": gh_url,
                }
            )
            continue

        text = _concat_text_fields(row, df_cols_lower)
        score, buckets, matched = _score_frontier(text, rules)

        strong_bucket_hits = sum(buckets.get(b, 0) for b in ("gpu", "inference", "train"))
        if strong_bucket_hits == 0:
            discard_rows.append(
                {
                    "row_index": idx,
                    "reason": "no_frontier_signal_buckets",
                    "GitHub_Username": gh_user,
                    "GitHub_URL": gh_url,
                    "score": int(score),
                    "matched_keywords": ";".join(matched[:25]),
                }
            )
            continue

        for kw in matched:
            keyword_freq[kw] = keyword_freq.get(kw, 0) + 1

        out_row = row.to_dict()
        out_row["Scenario"] = scenario
        out_row["Scenario_Score"] = int(score)
        out_row["Scenario_Buckets"] = ",".join(sorted(k for k, v in buckets.items() if v > 0))
        out_row["Scenario_Keywords"] = ";".join(matched[:40])
        accepted_rows.append(out_row)

    accepted_all = pd.DataFrame(accepted_rows)
    discards = pd.DataFrame(discard_rows)

    print(f"Accepted rows (pre-cap): {len(accepted_all)}")
    print(f"Discarded rows: {len(discards)}")

    # Hard minimum enforcement
    if len(accepted_all) < min_rows:
        outdir.mkdir(parents=True, exist_ok=True)
        stamp = _now_stamp()
        discards_path = outdir / f"{scenario}_discards_{stamp}.csv"
        discards.to_csv(discards_path, index=False)
        _hard_fail(
            f"People scenario resolution produced too few rows.\n"
            f"Scenario: {scenario}\n"
            f"Accepted (pre-cap): {len(accepted_all)}\n"
            f"Minimum required: {min_rows}\n"
            f"Discards written: {discards_path}\n"
            "Fix: broaden upstream enumeration terms or expand accepted signal rules (still real-data-only)."
        )

    # Deterministic ranking then demo cap
    accepted_all = accepted_all.sort_values(
        by=["Scenario_Score", "GitHub_Username"],
        ascending=[False, True],
        kind="mergesort",
    )

    pre_cap_count = len(accepted_all)
    accepted = accepted_all.head(max_rows).copy()
    post_cap_count = len(accepted)

    # Final identity sanity check
    non_empty_user = (accepted["GitHub_Username"].astype(str).str.strip() != "").sum()
    non_empty_url = (accepted["GitHub_URL"].astype(str).str.strip() != "").sum()
    if non_empty_user == 0 and non_empty_url == 0:
        _hard_fail(
            "Resolved people output is missing GitHub identity.\n"
            "This indicates upstream schema mismatch or identity extraction failure."
        )

    outdir.mkdir(parents=True, exist_ok=True)
    stamp = _now_stamp()
    out_path = outdir / f"{scenario}_people_{stamp}.csv"
    discards_path = outdir / f"{scenario}_discards_{stamp}.csv"
    status_path = outdir / f"{scenario}_people_status_{stamp}.txt"

    accepted.to_csv(out_path, index=False)
    discards.to_csv(discards_path, index=False)

    top_kws = sorted(keyword_freq.items(), key=lambda kv: (-kv[1], kv[0]))[:15]
    top_users = accepted["GitHub_Username"].astype(str).head(10).tolist()

    status_lines: List[str] = []
    status_lines.append(f"scenario={scenario}")
    status_lines.append(f"people_master={people_master_path}")
    status_lines.append(f"accepted_pre_cap={pre_cap_count}")
    status_lines.append(f"accepted_post_cap={post_cap_count}")
    status_lines.append(f"discarded_rows={len(discards)}")
    status_lines.append(f"min_required={min_rows}")
    status_lines.append(f"max_rows_demo_cap={max_rows}")
    status_lines.append(f"output_csv={out_path}")
    status_lines.append(f"discards_csv={discards_path}")
    status_lines.append(f"non_empty_github_username={non_empty_user}")
    status_lines.append(f"non_empty_github_url={non_empty_url}")
    status_lines.append(f"was_capped={'true' if pre_cap_count > max_rows else 'false'}")
    status_lines.append("top_keywords=" + ",".join([f"{k}:{v}" for k, v in top_kws]))
    status_lines.append("proof_first_usernames=" + ",".join([u for u in top_users if u.strip()]))

    status_path.write_text("\n".join(status_lines) + "\n", encoding="utf-8")

    print("\nSUCCESS: People scenario output generated")
    _soft_print_kv("people_csv", str(out_path))
    _soft_print_kv("discards_csv", str(discards_path))
    _soft_print_kv("status_file", str(status_path))
    print(f"Final people count (post-cap): {post_cap_count} (pre-cap: {pre_cap_count})")

    print("\nProof of resolution (first 10 GitHub usernames):")
    for i, u in enumerate(top_users, 1):
        if str(u).strip():
            print(f"  {i}. {u}")

    if top_kws:
        print("\nTop matched frontier keywords (frequency):")
        for k, v in top_kws:
            print(f"  - {k}: {v}")

    return out_path


def _parse_args(argv: List[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Resolve scenario-scoped PEOPLE CSV from outputs/people/people_master.csv (real data only)."
    )
    p.add_argument("--scenario", required=True, help="Scenario name (supported: frontier).")
    p.add_argument(
        "--people-master",
        default=str(DEFAULT_PEOPLE_MASTER),
        help="Path to outputs/people/people_master.csv",
    )
    p.add_argument(
        "--outdir",
        default=str(DEFAULT_OUTDIR),
        help="Output directory for scenario people CSVs (default: outputs/people/).",
    )
    p.add_argument(
        "--min-rows",
        type=int,
        default=DEFAULT_MIN_ROWS,
        help=f"Hard minimum accepted people rows; hard-fail if below. Default: {DEFAULT_MIN_ROWS}",
    )
    p.add_argument(
        "--max-rows",
        type=int,
        default=DEFAULT_MAX_ROWS,
        help=f"Demo cap maximum rows to write. Default: {DEFAULT_MAX_ROWS}",
    )
    return p.parse_args(argv)


def main(argv: List[str]) -> None:
    args = _parse_args(argv)
    resolve_people_scenario(
        scenario=args.scenario,
        people_master_path=Path(args.people_master),
        outdir=Path(args.outdir),
        min_rows=int(args.min_rows),
        max_rows=int(args.max_rows),
    )


if __name__ == "__main__":
    main(sys.argv[1:])
