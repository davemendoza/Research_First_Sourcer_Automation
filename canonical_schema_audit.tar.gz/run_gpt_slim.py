#!/usr/bin/env python3

<PASTE FULL run_gpt_slim.py CONTENT HERE>

